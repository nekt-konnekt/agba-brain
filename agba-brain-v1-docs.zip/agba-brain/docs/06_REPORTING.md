# Agba V1 Reporting

## 1. Goal

Reporting is the primary input mechanism through which department heads teach Agba what is happening in the company.

Reporting should feel like communication with a chief of staff, not bureaucracy.

## 2. Department-head reporting

A department head should be able to submit:

- A structured report
- A natural-language update
- A correction
- A follow-up
- A decision
- A new issue
- A clarification

## 3. Natural-language example

Input:

> "Sales was slow today. We closed ₦1.2m, two large customers pushed their orders to tomorrow, and Chidi says pricing is confusing."

Agba should extract:

```text
Department: Sales

Metric:
Revenue = ₦1.2m

Events:
Two large orders postponed

Observation:
Pricing may be causing customer confusion

Potential impact:
Revenue timing shifted
```

The original text remains the evidence source.

## 4. Reporting lifecycle

```text
Department Head
      ↓
Submit update
      ↓
Store original report
      ↓
Validate submission
      ↓
Extract structured entries
      ↓
Link entries to evidence
      ↓
Update company state
      ↓
Recalculate relevant observations
      ↓
Check issues / decisions / follow-ups
      ↓
Update briefing context
```

## 5. Report status

V1 statuses:

- draft
- submitted
- processing
- processed
- needs_clarification
- superseded

## 6. Required information

Do not make every report field mandatory.

At minimum, Agba should know:

- Department
- Reporting date/time
- Reporting user
- Main update

Everything else can be extracted or requested when necessary.

## 7. Follow-up questions

Agba should ask for clarification when missing information materially affects the company state.

Example:

> "You mentioned two orders slipped. Do you know whether the customers cancelled them or moved delivery to tomorrow?"

## 8. Corrections

A correction should preserve history.

Do not overwrite the original report without an audit trail.

Example:

Original:

> "Revenue was ₦1.2m."

Correction:

> "Correction: revenue was ₦1.05m. The ₦150k order was not actually paid."

Agba should update the normalized metric while retaining the original submission and correction evidence.

## 9. Missing reports

Agba should know when an expected department report has not arrived.

A missing report may become an attention item only if:

- The report is expected
- It is overdue
- The information is operationally important

## 10. Report quality

Agba should not reward verbosity.

A good report is one that gives enough reliable information to update company understanding.

## 11. Cross-department dependencies

Reports should be able to identify dependencies.

Example:

```text
Production
   ↓ needs
Procurement
   ↓ waiting on
Supplier
```

Agba should use these relationships when reasoning about risk.

## 12. Reporting does not equal truth

A report is a source.

Some information may be:

- Self-reported
- Estimated
- Confirmed
- Contradicted
- Pending verification

Agba should preserve that distinction.

## 13. Reporting and memory

Useful recurring information should become durable context only when there is enough evidence or an explicit confirmation.

A single casual comment should not automatically become permanent company policy.
