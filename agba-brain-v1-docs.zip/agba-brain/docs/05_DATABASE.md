# Agba V1 Database Model

## 1. Database goal

The database must represent the company's operational state and the evidence Agba uses to understand it.

It must not become a dump of unstructured chat messages.

## 2. Organization and identity

### organizations

Represents a company using Agba.

Core fields:

- id
- name
- created_at
- updated_at

### users

Application user identity linked to Supabase Auth.

Core fields:

- id
- organization_id
- email
- display_name
- role_id
- department_id
- status
- created_at
- updated_at

### roles

Defines broad authority.

V1 roles:

- CEO
- Department Head

The model should remain extensible.

### departments

Represents company departments.

Core fields:

- id
- organization_id
- name
- description
- head_user_id
- active
- created_at
- updated_at

## 3. Reporting

### reports

A submitted department report.

Core fields:

- id
- organization_id
- department_id
- submitted_by
- report_date
- source_type
- raw_content
- status
- created_at
- updated_at

### report_entries

Normalized pieces extracted from reports.

Examples:

- metric
- issue
- task
- event
- expense
- revenue
- observation

Core fields:

- id
- report_id
- entry_type
- title
- description
- structured_data
- confidence
- created_at

Original report content must remain available as evidence.

## 4. Operational entities

### metrics

Stores measured company or department values.

Examples:

- revenue
- orders
- output
- expenses
- completion rate

Fields:

- id
- organization_id
- department_id
- name
- value
- unit
- metric_date
- target
- source_reference
- created_at

### tasks

Fields:

- id
- organization_id
- department_id
- title
- description
- owner_user_id
- status
- priority
- due_at
- created_at
- updated_at

### expenses

Fields:

- id
- organization_id
- department_id
- amount
- currency
- description
- expense_date
- submitted_by
- status
- source_reference
- created_at

### revenue_records

Fields:

- id
- organization_id
- department_id
- amount
- currency
- revenue_date
- source_reference
- created_at

### events

Records meaningful company events.

Fields:

- id
- organization_id
- department_id
- event_type
- title
- description
- occurred_at
- source_reference
- created_at

## 5. Intelligence entities

### observations

Structured understanding derived from facts.

Fields:

- id
- organization_id
- department_id
- type
- statement
- confidence
- status
- created_at
- updated_at

An observation must be traceable to evidence.

### issues

Tracks unresolved problems.

Fields:

- id
- organization_id
- department_id
- title
- description
- severity
- status
- owner_user_id
- detected_at
- resolved_at
- created_at
- updated_at

### decisions

Tracks decisions made by authorized users.

Fields:

- id
- organization_id
- department_id
- title
- decision
- decision_maker_user_id
- decided_at
- expected_outcome
- status
- created_at
- updated_at

### approvals

Tracks items waiting for authorized approval.

Fields:

- id
- organization_id
- department_id
- title
- description
- requested_by
- approver_user_id
- status
- requested_at
- resolved_at

### goals

Represents targets and objectives.

Fields:

- id
- organization_id
- department_id
- title
- description
- target_value
- unit
- period_start
- period_end
- status

## 6. Context and memory

### context_items

Stores durable operational context that remains useful beyond a single report.

Examples:

- recurring supplier issue
- agreed process
- important customer constraint
- known dependency
- historical operating pattern

Fields:

- id
- organization_id
- department_id
- title
- content
- context_type
- confidence
- valid_from
- valid_until
- created_at
- updated_at

### relationships

Connects company entities.

Examples:

- issue affects task
- task blocks order
- department depends on department
- observation supported_by report

Fields:

- id
- organization_id
- source_type
- source_id
- relationship_type
- target_type
- target_id
- created_at

## 7. Conversations

### conversations

Stores an Agba interaction thread.

Fields:

- id
- organization_id
- user_id
- department_id
- conversation_type
- created_at
- updated_at

### messages

Stores user and Agba messages.

Fields:

- id
- conversation_id
- role
- content
- created_at

Conversation messages are not automatically treated as company facts. Useful facts should be explicitly extracted and linked to evidence.

## 8. Evidence

### evidence_links

Connects intelligence objects to source records.

Fields:

- id
- organization_id
- source_type
- source_id
- target_type
- target_id
- relevance
- created_at

## 9. Audit

### audit_logs

Records important system actions.

Fields:

- id
- organization_id
- actor_user_id
- action
- resource_type
- resource_id
- metadata
- created_at

## 10. Security

All organization-owned tables must enforce organization isolation.

Role and department authorization must be applied through database policies and server-side authorization.

The LLM must never determine whether a user is allowed to access a record.

## 11. Database design rule

Prefer normalized source data plus explicit intelligence records over one giant "company brain" JSON object.

The brain is the behavior of the system over the data, not a single magic database field.
