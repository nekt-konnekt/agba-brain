# Agba V1 Architecture

## 1. Architectural goal

Build one shared company intelligence layer that receives information from department heads and operational systems, converts it into structured company knowledge, maintains historical context, and serves role-aware intelligence to users.

## 2. High-level flow

```text
Department Heads
      │
      ├── Reports
      ├── Conversations
      ├── Corrections
      └── Decisions / updates
      │
      ▼
Reporting Ingestion
      │
      ▼
Normalization + Validation
      │
      ▼
Company Facts
      │
      ├── Metrics
      ├── Tasks
      ├── Expenses
      ├── Revenue
      ├── Events
      └── Report entries
      │
      ▼
Agba Intelligence Layer
      │
      ├── Observations
      ├── Issues
      ├── Decisions
      ├── Relationships
      ├── Historical Context
      └── Memory
      │
      ▼
Role-aware Retrieval
      │
      ├───────────────┬──────────────────┐
      ▼               ▼                  ▼
Department Head      CEO           Agba's Office
      │               │                  │
      ▼               ▼                  ▼
 Ask Agba       Briefing + Ask       Executive view
```

## 3. Core architectural layers

### Identity and access

Determines:

- Organization
- User
- Role
- Department
- Permissions

This layer constrains what information may enter a user's context.

### Company data layer

Stores structured operational records.

### Intelligence layer

Builds higher-level company understanding from raw records.

### Retrieval layer

Selects relevant authorized context for a question or briefing.

### Reasoning layer

Produces interpretations, summaries, risk assessments, and recommendations.

### Presentation layer

Serves:

- Ask Agba
- Agba's Briefing
- Agba's Office

## 4. Same brain, scoped views

```text
                    Company Intelligence
                           │
              ┌────────────┴────────────┐
              │                         │
             CEO                  Department Head
              │                         │
       broad authorized          department-scoped
           context                   context
```

The data model must support shared company context without duplicating it per user.

## 5. Reporting ingestion

Reports can arrive as:

- Structured report fields
- Natural-language messages
- Follow-up messages
- Corrections

Ingestion should preserve the original submission while creating normalized records.

## 6. Evidence chain

Every important intelligence object should have a path back to source evidence.

```text
Conclusion
   ↓
Observation / reasoning record
   ↓
Supporting facts
   ↓
Source report / metric / event
```

## 7. Intelligence objects

V1 should support:

- Facts
- Observations
- Issues
- Decisions
- Tasks
- Events
- Goals
- Metrics
- Context
- Evidence links

## 8. Deterministic vs AI responsibilities

### Deterministic

Prefer code/database rules for:

- Authentication
- Authorization
- Organization isolation
- Data validation
- Numeric calculations
- Aggregations
- Permission checks
- Audit logging
- State transitions

### AI

Use the model for:

- Natural-language understanding
- Extraction from conversational reports
- Summarization
- Classification
- Contextual reasoning
- Explanation
- Draft recommendations
- Briefing composition

AI must not be the final authority for access control.

## 9. Company isolation

Every organization-owned record must be scoped to an organization.

Cross-company data leakage must be prevented at the data access layer.

Supabase Row Level Security should be part of the security architecture.

## 10. Agba's Office

Agba's Office is a read-oriented executive presentation of company intelligence.

It should not maintain a separate source of truth.

Its data should be derived from the same intelligence and operational records used by Ask Agba and Agba's Briefing.

## 11. V1 technology direction

Recommended stack:

- Frontend: Next.js
- Language: TypeScript
- Backend/API: Next.js server-side capabilities
- Database: Supabase PostgreSQL
- Auth: Supabase Auth
- Row Level Security: PostgreSQL/Supabase RLS
- AI orchestration: application-level TypeScript services
- Model provider: configurable LLM provider
- Deployment: Vercel
- Repository: `agba-brain`

## 12. Architectural rule

Do not build the dashboard first.

Build the company intelligence layer first, then expose it through the CEO and department-head interfaces.
