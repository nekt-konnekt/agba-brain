# Agba V1 CEO Experience

## 1. Goal

The CEO experience should answer:

> **What do I need to know right now?**

The CEO should not have to manually inspect every department report.

## 2. Three CEO interfaces

### Agba's Briefing

Agba proactively summarizes the company's important state.

### Ask Agba

The CEO can ask any authorized company question.

### Agba's Office

A visual executive cockpit for quick inspection.

All three use the same company intelligence layer.

## 3. Agba's Briefing

A typical briefing should contain:

1. Overall company pulse
2. Significant changes
3. Attention items
4. Pending decisions
5. Important department updates
6. Key metrics
7. Relevant recommendations

The briefing should be concise by default.

## 4. Example briefing

```text
GOOD MORNING.

Company is stable, but there are 3 things I think you should know.

1. Production
   Order 1042 may miss tomorrow's delivery because material has not arrived.

2. Sales
   Revenue is below today's pace, mainly because two large orders moved to tomorrow.

3. Finance
   ₦680k in expenses is waiting for verification.

2 decisions are waiting for you.

I would prioritize the production issue first because it has a confirmed
customer deadline.
```

## 5. Ask Agba

CEO questions may include:

- "What is worrying you most?"
- "Why is Production behind?"
- "How much did we spend this week?"
- "Which department is underperforming?"
- "What decisions are waiting for me?"
- "Has this problem happened before?"
- "Show me the evidence."

Agba should answer using authorized company context.

## 6. Agba's Office

Agba's Office is not a general BI dashboard.

Its purpose is quick executive orientation.

### Recommended sections

#### Company Pulse

A concise current status with explanation.

#### Today

Key operational numbers.

#### Attention

Issues Agba believes require attention.

#### Departments

High-level department status.

#### Decisions

Pending decisions and approvals.

#### Key Numbers

A small number of relevant KPIs.

#### Recent Reports

Recent department activity.

#### Agba's Briefing

The latest executive summary.

#### Ask Agba

A persistent conversational entry point.

## 7. Office example

```text
AGBA'S OFFICE
Monday, 17 August

COMPANY PULSE
ATTENTION

Revenue today      ₦1.84m
Expenses today     ₦420k
Task completion    87%

ATTENTION

Production
Material shortage may affect Order 1042.

Sales
Revenue is below target pace.

Finance
₦680k expense requires verification.

DEPARTMENTS

Sales          Attention
Production     At risk
Finance        Attention
Marketing      Stable

DECISIONS

2 waiting for you

ASK AGBA
"What should I deal with first?"
```

## 8. Drill-down

Every significant item should allow the CEO to inspect supporting context.

Example:

```text
Attention
   ↓
Issue
   ↓
Why Agba flagged it
   ↓
Supporting observations
   ↓
Reports / metrics / events
```

## 9. CEO attention rules

Do not fill the screen with every event.

Prioritize:

- Material business impact
- Urgent deadlines
- Cross-department blockers
- Significant target deviations
- Repeated problems
- Decisions requiring CEO authority

## 10. CEO permissions

The CEO receives broad company intelligence subject to organization-level policy.

The CEO should still see clear evidence and confidence levels for important conclusions.

## 11. Department heads in the same system

Department heads do not use Agba's Office as their primary experience.

They use Ask Agba and reporting flows scoped to their authority.

The CEO sees the broader synthesized company state.

## 12. V1 design rule

The visual experience should be simple enough that the CEO can understand the company's current state in under a minute, then ask Agba for the deeper answer.
