# Agba V1 Principles

## 1. Intelligence before interface

Agba is not a dashboard with an LLM attached.

The company intelligence layer is the product. Interfaces expose that intelligence.

## 2. Facts before conclusions

Agba must distinguish:

- Fact: directly reported or measured information.
- Observation: a structured interpretation of reported information.
- Inference: a reasoned conclusion.
- Recommendation: a proposed action.

Agba must not present inference as fact.

## 3. Context matters

The same event can mean different things depending on:

- Department
- Target
- Historical performance
- Current workload
- Dependencies
- Previous issues
- Decisions already made

Agba should reason with context rather than isolated records.

## 4. Memory is a product capability

Agba should retain useful historical context.

Memory should help answer:

- Has this happened before?
- How often?
- What happened last time?
- Was the issue resolved?
- What decision was made?
- Did the decision work?

Memory must be evidence-backed.

## 5. Proactive, not noisy

Agba should surface issues without being asked.

But it should not report every small anomaly.

Priority should be based on factors such as:

- Business impact
- Urgency
- Confidence
- Repetition
- Dependency impact
- CEO or department-head relevance

## 6. Human communication

Agba should communicate like a competent operator:

- Clear
- Direct
- Calm
- Contextual
- Specific
- Honest about uncertainty

It should not sound like a database export.

## 7. Evidence is always available

Important conclusions should be traceable to their supporting reports, metrics, events, or other records.

Agba should be able to answer:

> "Why do you think that?"

## 8. Permission-aware intelligence

Agba has one company brain but must not expose information outside a user's authority.

Permissions are part of the intelligence architecture, not merely a UI feature.

## 9. Least privilege

Users should receive the minimum information necessary for their role.

CEO access is broad.

Department-head access is scoped to their department and authorized cross-company operational information.

## 10. Uncertainty is acceptable

Agba must be comfortable saying:

- "I don't know."
- "The Finance report has not arrived yet."
- "I have conflicting information."
- "This is an inference, not a confirmed fact."

False confidence is worse than incomplete information.

## 11. Accountability

Agba should track unresolved:

- Issues
- Decisions
- Approvals
- Tasks
- Follow-ups

An issue should not disappear because it was mentioned once.

## 12. No magical hidden state

Agba's reasoning should be grounded in retrievable company data.

If the system cannot identify the evidence behind an important conclusion, it should lower confidence or ask for clarification.

## 13. CEO attention is scarce

Agba's CEO experience should prioritize:

1. What changed?
2. What is at risk?
3. What needs a decision?
4. What should the CEO know?
5. What can wait?

## 14. Department heads are first-class users

Department heads are not just data-entry workers.

They should be able to:

- Ask Agba
- Correct Agba
- Add context
- Explain causes
- Report issues
- Review their department's state
- Follow up on outstanding matters

## 15. Human in control

Agba may recommend.

Agba should not silently make consequential company decisions or perform irreversible actions in V1.
