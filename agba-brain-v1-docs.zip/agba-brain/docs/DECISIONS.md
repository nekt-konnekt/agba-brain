# Agba V1 Architectural Decisions

## Decision 001: Product identity

Product name: **Agba**

Repository name: **agba-brain**

## Decision 002: Core product model

Agba is a company operating brain and AI chief of staff, not a dashboard product.

## Decision 003: Shared brain

Agba maintains one company intelligence layer.

CEO and department heads access different authorized scopes of the same underlying company knowledge.

## Decision 004: Department heads are first-class users

Department heads can both report to Agba and ask Agba operational questions in V1.

## Decision 005: CEO interface

The CEO receives:

- Agba's Briefing
- Ask Agba
- Agba's Office

## Decision 006: Agba's Office

Agba's Office is a compact executive cockpit, not a general-purpose BI dashboard.

## Decision 007: Permission architecture

Authorization is enforced outside the LLM.

The model cannot grant itself access to company data.

## Decision 008: Evidence

Important observations, issues, recommendations, and briefings should be traceable to source evidence where applicable.

## Decision 009: Human control

Agba recommends and informs. Authorized humans make consequential decisions in V1.

## Decision 010: Build order

Documentation and data architecture come before the visual cockpit.

## Decision 011: Natural reporting

Department heads should be able to communicate naturally. Structured extraction happens behind the scenes.

## Decision 012: Memory

Agba should retain useful operational context and historical patterns, but memory must remain evidence-backed.
