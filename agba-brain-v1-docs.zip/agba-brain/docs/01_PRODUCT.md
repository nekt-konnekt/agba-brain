# Agba V1 Product Definition

## 1. Product

**Agba** is an AI company operating brain and executive chief of staff.

Agba receives operational information from department heads, understands it in company context, remembers what has happened, identifies important changes and unresolved problems, and communicates what matters to the appropriate person.

Agba is not primarily a dashboard. It is the intelligence layer underneath the company.

## 2. The problem

Companies generate information continuously:

- Department reports
- Sales activity
- Expenses
- Tasks
- Orders
- Operational problems
- Decisions
- Approvals
- Targets
- Customer issues
- Delays
- Dependencies between departments

The information is usually fragmented. Leadership has to manually collect it, interpret it, remember historical context, and decide what deserves attention.

Agba reduces that operational fragmentation.

## 3. Core product promise

> **Agba helps the company know what is happening, understand why it matters, remember what happened before, and tell the right person what needs attention.**

## 4. Users

### CEO

The CEO receives company-wide intelligence.

The CEO can:

- Receive Agba's Briefing
- Ask questions about the company
- Review important issues
- Review pending decisions
- Inspect department status
- Examine metrics and trends
- Trace conclusions back to evidence
- Use Agba's Office for a visual company view

### Department Head

Department heads are active users of Agba.

They can:

- Submit reports
- Talk to Agba about their department
- Ask questions about their operation
- Review department metrics
- Track tasks and issues
- Report changes conversationally
- Follow up on unresolved problems
- Access company information relevant to their authority

## 5. One company brain

Agba maintains one shared company intelligence layer.

Users do not receive separate copies of company knowledge.

Their identity, role, department, and permissions determine what Agba can expose to them.

```text
Company information
        ↓
Agba company intelligence
        ↓
Role-aware retrieval
        ↓
CEO or Department Head
```

## 6. Human interaction model

Agba should feel like a highly capable chief of staff or operations director.

It should communicate naturally, explain context, distinguish facts from inference, acknowledge uncertainty, and proactively surface important matters.

A department head should be able to say:

> "Production was slow today. Two orders slipped because we didn't receive the material."

Agba should extract useful facts and context without forcing the user to complete a rigid form.

## 7. V1 interfaces

### Agba's Briefing

A proactive executive summary.

### Ask Agba

Conversational access to authorized company intelligence.

### Agba's Office

A compact visual executive cockpit.

It should answer:

> "What do I need to know right now?"

It should not attempt to become a general BI platform.

## 8. V1 intelligence

Agba should understand:

- Departments
- Department heads
- Reports
- Observations
- Metrics
- Tasks
- Expenses
- Revenue
- Issues
- Decisions
- Approvals
- Events
- Goals and targets
- Historical context
- Evidence and sources

## 9. V1 exclusions

Do not build V1 around:

- A full enterprise ERP
- A general-purpose BI builder
- A custom dashboard designer
- Complex workflow automation
- Payroll processing
- Full accounting
- Full CRM
- Employee surveillance
- Enterprise IAM complexity
- Autonomous financial transactions

## 10. Success criteria

V1 succeeds if:

1. A company can be set up quickly.
2. Department heads can report naturally.
3. Agba can turn reports into structured company observations.
4. Agba remembers relevant historical context.
5. Agba can identify important issues and decisions.
6. Department heads can ask useful operational questions.
7. The CEO receives a concise, trustworthy briefing.
8. The CEO can inspect Agba's Office.
9. Permission boundaries are enforced.
10. Important Agba conclusions can be traced to evidence.

## 11. Product vocabulary

Use:

- Agba
- Agba's Briefing
- Ask Agba
- Agba's Office
- Company Intelligence
- Agba's Memory
- Attention
- Decisions
- Department Reports

Avoid making "dashboard" the user-facing product concept.
