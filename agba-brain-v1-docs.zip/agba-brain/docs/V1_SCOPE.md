# Agba V1 Scope

## Build

- Organization setup
- CEO account
- Department creation
- Department-head accounts
- Role-aware permissions
- Department reporting
- Conversational reporting
- Report extraction
- Company facts
- Metrics
- Tasks
- Expenses
- Revenue
- Issues
- Decisions
- Observations
- Evidence links
- Basic historical context
- Ask Agba
- Agba's Briefing
- Agba's Office
- Audit logging

## Do not build yet

- Full accounting
- Payroll
- Full CRM
- Full ERP
- General dashboard builder
- Complex automation engine
- Advanced workflow designer
- Enterprise IAM
- Autonomous payments
- Employee surveillance
- Large-scale data warehouse
- Fine-grained custom permission designer

## V1 quality bar

The system should favor trustworthy company understanding over feature count.
