# Agba V1 End-to-End Flow

## 1. Company setup

```text
Create organization
      ↓
Create CEO
      ↓
Create departments
      ↓
Assign department heads
      ↓
Define basic targets / reporting expectations
      ↓
Agba is ready
```

## 2. Department reporting flow

```text
Department Head
      ↓
"Agba, here's what happened today..."
      ↓
Conversation / report
      ↓
Original content stored
      ↓
Extraction
      ↓
Facts + observations + events + tasks + issues
      ↓
Evidence links
      ↓
Company state updated
```

## 3. Agba reasoning flow

```text
New company information
      ↓
Retrieve relevant history
      ↓
Check targets and existing state
      ↓
Check related departments / dependencies
      ↓
Detect changes
      ↓
Detect unresolved issues
      ↓
Assess significance
      ↓
Update observations
      ↓
Update attention items
      ↓
Update decision context
```

## 4. Department-head question flow

```text
Department Head
      ↓
Ask Agba
      ↓
Identify user + department + permissions
      ↓
Retrieve authorized context
      ↓
Reason over context
      ↓
Answer
      ↓
Offer evidence / next action where useful
```

## 5. CEO briefing flow

```text
Company state
      ↓
Recent changes
      ↓
Open issues
      ↓
Pending decisions
      ↓
Department performance
      ↓
Relevant historical context
      ↓
Priority ranking
      ↓
Agba's Briefing
```

## 6. Agba's Office flow

```text
Company intelligence
      ↓
Current pulse
      ↓
Key metrics
      ↓
Attention items
      ↓
Department states
      ↓
Pending decisions
      ↓
Recent activity
      ↓
Agba's Office
```

## 7. Evidence flow

```text
Agba conclusion
      ↓
Observation
      ↓
Evidence links
      ↓
Source report / metric / event
```

## 8. Correction flow

```text
User correction
      ↓
Store correction
      ↓
Preserve original record
      ↓
Update normalized state
      ↓
Recalculate affected observations
      ↓
Update briefing / attention if necessary
```

## 9. Missing information flow

```text
Required report missing
      ↓
Determine importance
      ↓
If material:
    create attention / follow-up
      ↓
Otherwise:
    wait
```

## 10. Human control flow

```text
Agba detects
      ↓
Agba explains
      ↓
Agba recommends
      ↓
Authorized human decides
      ↓
Decision recorded
      ↓
Agba remembers outcome
```

Agba does not silently make consequential company decisions in V1.
