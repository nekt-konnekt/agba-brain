# Agba

Agba is an AI company operating brain and executive chief of staff.

Repository: `agba-brain`

Agba receives information from department heads, builds a living understanding of the company, identifies what matters, and communicates it to the right person.

## V1 interfaces

1. Department Heads talk to Agba and submit reports.
2. Agba maintains shared company knowledge and memory.
3. The CEO receives Agba's Briefing.
4. The CEO can ask Agba questions.
5. The CEO can inspect **Agba's Office**, a compact executive view of the current company state.

## Core access model

```text
                         AGBA
                          │
              Company Knowledge + Memory
                          │
             ┌────────────┴────────────┐
             │                         │
            CEO                  Department Head
             │                         │
             ▼                         ▼
       Full company              Department
       intelligence              intelligence
             │                         │
             └────────────┬────────────┘
                          │
                    Same Company Brain
```

The CEO and department heads do not use separate brains. They access the same company intelligence through role-aware permissions.

## Implementation order

```text
01  Product definition
        ↓
02  Product principles
        ↓
03  Agba behaviour
        ↓
04  Architecture
        ↓
05  Database model
        ↓
06  Reporting system
        ↓
07  CEO experience
        ↓
08  Supabase schema / migrations
        ↓
09  Company setup
        ↓
10  Reporting ingestion
        ↓
11  Agba reasoning / briefing
        ↓
12  Agba's Office
```

## Documentation

- `docs/01_PRODUCT.md`
- `docs/02_PRINCIPLES.md`
- `docs/03_AGBA_BEHAVIOR.md`
- `docs/04_ARCHITECTURE.md`
- `docs/05_DATABASE.md`
- `docs/06_REPORTING.md`
- `docs/07_CEO_EXPERIENCE.md`
- `docs/FLOW.md`
- `docs/V1_SCOPE.md`
- `docs/DECISIONS.md`

These documents are the V1 source of truth before implementation.
