# Agba Supabase schema

These migrations are applied to the connected Supabase project.

## Migration history

- `20260817103323_001_agba_v1_core_schema.sql`
  - Core Agba V1 entities
  - enums
  - indexes
  - timestamps
  - RLS
  - CEO / Department Head access model
  - evidence, conversations, audit logs

- `20260817103400_002_agba_security_hardening.sql`
  - hardened trigger function search path
  - removed direct RPC execution of Agba identity helpers

- `20260817103500_003_agba_private_security_functions.sql`
  - moved Agba SECURITY DEFINER identity helpers into a private schema
  - removed schema access for API roles

## Important naming decision

The connected Supabase project already contains unrelated application tables, including a `public.users` table.

To avoid destructive changes or collisions, Agba V1 tables use the `agba_` prefix:

- `agba_organizations`
- `agba_roles`
- `agba_users`
- `agba_departments`
- `agba_reports`
- `agba_report_entries`
- `agba_metrics`
- `agba_tasks`
- `agba_expenses`
- `agba_revenue_records`
- `agba_events`
- `agba_observations`
- `agba_issues`
- `agba_decisions`
- `agba_approvals`
- `agba_goals`
- `agba_context_items`
- `agba_relationships`
- `agba_conversations`
- `agba_messages`
- `agba_evidence_links`
- `agba_audit_logs`

The product-level model remains exactly the one defined in `docs/05_DATABASE.md`. The `agba_` prefix is an implementation namespace only.

## Access model

```text
                         AGBA
                          │
              Company Knowledge + Memory
                          │
             ┌────────────┴────────────┐
             │                         │
            CEO                  Department Head
             │                         │
             ▼                         ▼
       Full company              Department
       intelligence              intelligence
```

Authorization is enforced by PostgreSQL RLS. The LLM does not decide whether a user may access a record.

## Current state

The migrations have been successfully applied to the connected Supabase project.
